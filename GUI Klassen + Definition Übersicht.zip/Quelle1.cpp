Line::Line(Point p1, Point p2) // construct a line from two points
{
	add(p1); // add p1 to this shape
	add(p2); // add p2 to this shape
}

// LINES
void Lines::add(Point p1, Point p2)
{
	Shape::add(p1);
	Shape::add(p2);
}

void Lines::draw_lines() const
{
	if (color().visibility())
		for (int i = 1; i < number_of_points(); i += 2)
			fl_line(point(i�1).x, point(i�1).y, point(i).x, point(i).y);
}

// CLOSED POLYLINE
void Closed_polyline::draw_lines() const
{
	Open_polyline::draw_lines(); // first draw the �open polyline part� then draw closing line:
	if (2 < number_of_points() && color().visibility())
		fl_line(point(number_of_points()�1).x,
			point(number_of_points()�1).y,
			point(0).x,
			point(0).y);
}

// POLYGON
void Polygon::add(Point p)
{
	// check that the new line doesn�t intersect existing lines (code not shown)
	Closed_polyline::add(p);
}

// RECTANGLE
Rectangle::Rectangle(Point xy, int ww, int hh)
	: w{ ww }, h{ hh }
{
	if (h <= 0 || w <= 0)
		error("Bad rectangle: non-positive side");
	add(xy);
}

Rectangle::Rectangle(Point x, Point y)
	:w{ y.x�x.x }, h{ y.y�x.y }
{
	if (h <= 0 || w <= 0)
		error("Bad rectangle: first point is not top left");
	add(x);
}

void Rectangle::draw_lines() const
{
	if (fill_color().visibility()) { // fill
		fl_color(fill_color().as_int());
		fl_rectf(point(0).x, point(0).y, w, h);
	}
	if (color().visibility()) { // lines on top of fill
		fl_color(color().as_int());
		fl_rect(point(0).x, point(0).y, w, h);
	}
}

// TEXT
void Text::draw_lines() const
{
	fl_draw(lab.c_str(), point(0).x, point(0).y);
}

// CIRCLE
Circle::Circle(Point p, int rr) // center and radius
	:r{ rr }
{
	add(Point{ p.x�r,p.y�r }); // store top left corner
}

Point Circle::center() const
{
	return { point(0).x + r, point(0).y + r };
}

void Circle::draw_lines() const
{
	if (color().visibility())
		fl_arc(point(0).x, point(0).y, r + r, r + r, 0, 360);
}

// MARKED POLYLINE
Marked_polyline(const string& m, initializer_list<Point> lst)
	:Open_polyline{ lst },
	mark{ m }
{
	if (m == "") mark = "*";
}

void Marked_polyline::draw_lines() const
{
	Open_polyline::draw_lines();
	for (int i = 0; i < number_of_points(); ++i)
		draw_mark(point(i), mark[i % mark.size()]);
}

void draw_mark(Point xy, char c)
{
	constexpr int dx = 4;
	constexpr int dy = 4;
	string m{ 1,c }; // string holding the single char c
	fl_draw(m.c_str(), xy.x�dx, xy.y + dy);
}

// MARKS
struct Mark : Marks {
	Mark(Point xy, char c) : Marks{ string{1,c} }
	{
		add(xy);
	}
}

// IMAGE
Image::Image(Point xy, string s, Suffix e)
	:w{ 0 }, h{ 0 }, fn{ xy,"" }
{
	add(xy);
	if (!can_open(s)) { // can we open s?
		fn.set_label("cannot open \"" + s + '"');
		p = new Bad_image(30, 20); // the �error image�
		return;
	}
	if (e == Suffix::none) e = get_encoding(s);
	switch (e) { // check if it is a known encoding
	case Suffix::jpg:
		p = new Fl_JPEG_Image{ s.c_str() };
		break;
	case Suffix::gif:
		p = new Fl_GIF_Image{ s.c_str() };
		break;
	default: // unsupported image encoding
		fn.set_label("unsupported file type \"" + s + '"');
		p = new Bad_image{ 30,20 }; // the �err or image�
	}
}

bool can_open(const string& s)
// check if a file named s exists and can be opened for reading
{
	ifstream ff(s);
	return ff;
}