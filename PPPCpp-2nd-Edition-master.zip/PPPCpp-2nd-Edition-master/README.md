# PPPCpp-2nd-Edition
Lösungen zu den Drills und Exercises aus dem Buch "Programming: Principles and Practise using C++ (2nd Edition) - Bjarne Stroustrup".

Template-Datei um Visual Studio Projekt erstellen zu können: FLTK-1.3.5_Stroustrup (Project)
Template-Datei um Visual Studio Projekt erstellen zu können: FLTK-1.3.5 (Project)

Wichtig: Die mit CMAKE erstellte FLTK-Library und muss in folgendes Verzeichnis kopiert werden: C:\DEV Libraries\fltk-1.3.5 - nur so funktionieren die Templates. Bei abweichendem Verzeichnis muss die Projektvorlage entsprechend geändert werden.
